#include "admin.h"
admin::admin()
{
	
}
void admin::Verifyuser()
{
	adminlist::Verifyuser();
}

admin::~admin()
{
}

void admin::Deleteadmin()
{
	int id;
	cout << "\n\t Enter admin-id id to delete : ";
	cin >> id;
	ifstream fin("Asignup.dat", ios::binary);
	if (!fin)
	{
		cout << "\n\t Unable to open the file! ";
	}
	else
	{
		ofstream fout("temp.dat", ios::binary);
		if (!fout)
		{
			cout << "\n\tUnable to open the file!  ";
		}

		while (!fin.eof())
		{
			fin.read((char *)this, sizeof(*this));
			if (admin_id != id)
			{
				fout.write((char *)this, sizeof(this));
			}
			fin.read((char *)this, sizeof(*this));
		}
		fin.close();
		fout.close();
		remove("Asignup.dat");
		rename("temp.dat", "Asignup.dat");
	}
}
void admin::AddMember()
{
	member m;
	m.Signup();
}

void admin::deleteMember()
{
	member m;
	m.deleteMember();
}

void admin::Display()
{
	cout << "\n\t Status : " << status;
	cout << "\n\t Admin name : " << name;
	cout << "\n\t Admin age : " << age;
	cout << "\n\t Admin id : " << admin_id;
	cout << "\n\t Password : " << password;
	cout << "\n\t Email : " << email;
	cout << "\n\t Country : " << country;
	cout << "\n\t Phone : " << phone;
}
void admin::Signup()
{
	cout << "\n\t --------------SIGN UP----------------\n";
	cout << "\n" << "\tEnter an adminid of your choice : ";
	cin >> admin_id;
	cout << "\n\t Enter your password : ";
	cin >> password;
	cout << "\n\t Enter admin's name : ";
	cin >> name;
	cout << "\n\t Enter admin's age : ";
	cin >> age;
	cout << "\n\t Enter email of admin : ";
	cin >> email;
	cout << "\n\t Enter country of admin : ";
	cin >> country;
	cout << "\n\t Enter phone of admin : ";
	cin >> phone;
	ofstream of("Asignup.dat", ios::app | ios::binary);
	if (!of)
		cout << "\n Unable to open the file! ";
	else
	{
		of.write((char *)this, sizeof(*this));
		cout << "\n\t Account Created Successfully! \n";
	}
	of.close();
}

void admin::Login()
{
	bool flag = true;
	int ad;
	string p;
	cout << "\n\t*************** ADMIN-LOGIN *************** \n";
	cout << "\n" << "\tEnter your adminid : ";
	cin >> ad;
	cout << "\n\t Enter your password : ";
	cin >> p;
	ifstream r("Asignup.dat", ios::binary);
	if (!r)
		cout << "\n\t Unable to open the file ! ";
	else
	{
		while (!r.eof())
		{
			r.read((char *)this, sizeof(*this));
			if (p == password && ad == admin_id)
			{
				system("cls");
				cout << "\n\t Login Successful ! \n ";
				cout << "\n\t----------------ADMIN MENU--------------------\n";
			}
			else
				flag = false;
		}
		if (flag == false)
		{
			system("cls");
			cout << "\n\t Invalid id or password! Try again \n";
			Login();
		}
	}
	r.close();

}

void admin::viewadmins()
{
	ifstream r("Asignup.dat",ios::binary);
	cout << "\n\t ADMIN DETAILS \n";
	while (!r.eof())
	{
		if (!r.read((char *)this, sizeof(*this)))break;
		Display();
		cout << "\n";
	}
	r.close();
}