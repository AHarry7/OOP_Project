#include "memberlist.h"


memberlist::memberlist()
{
	name = "";
	age = 0;
	Email = "";
	cnic = 0;
	phone = 0;
}


memberlist::~memberlist()
{
}

void memberlist::Verifyuser()
{
	cout << "\n The user is a Member ! \n";
}