#pragma once
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
class adminlist
{
protected:
	string name;
	string status;
	string country;
	int age, phone;
	string email;
	int admin_id;
	string password;
	adminlist();
	~adminlist();
	void Verifyuser();
};

