#include "member.h"

member::member()
{
	memberid = 1234;
	paSS = "harry";
	status = "Member";
}
member::~member()
{
}
void member::set(int m, string p)
{
	memberid = m;
	paSS = p;
}
void member::Verifyuser()
{
	memberlist::Verifyuser();
}

void member::deleteMember()
{
	int id;
	cout << "\n\t Enter a member id to delete : ";
	cin >> id;
	ifstream fin("Msignup.dat", ios::binary);
	if (!fin)
	{
		cout << "\n\t Unable to open the file! ";
	}
	else
	{
		ofstream fout("temp.dat", ios::binary);
		if (!fout)
		{
			cout << "\n\t Unable to open ";
		}

		while (!fin.eof())
		{
			fin.read((char *)this, sizeof(*this));
			if (memberid != id)
			{
				fout.write((char *)this, sizeof(this));
			}
			fin.read((char *)this, sizeof(*this));
		}
		fin.close();
		fout.close();
		remove("Msignup.dat");
		rename("temp.dat", "Msignup.dat");
	}
}

void member::Display()
{
	cout << "\n\t Status : " << status;
	cout << "\n\t member name : " << name;
	cout << "\n\t member age : " << age;
	cout << "\n\t Member id : " << memberid;
	cout << "\n\t Password : " << paSS;
	cout << "\n\t email : " << Email;
	cout << "\n\t cnic : " << cnic;
	cout << "\n\t phone : " << phone;
}

void member::Signup()
{
	cout << "\n\t --------------SIGN UP----------------\n";
	cout << "\n " << "\tEnter a memberid of your choice : ";
	cin >> memberid;
	cout << "\n\t Enter your password : ";
	cin >> paSS;
	cout << "\n\t Enter member's name : ";
	cin >> name;
	cout << "\n\t Enter member's age : ";
	cin >> age;
	cout << "\n\t Enter email of member : ";
	cin >> Email;
	cout << "\n\t Enter cnic of member : ";
	cin >> cnic;
	cout << "\n\t Enter phone of member's : ";
	cin >> phone;
	ofstream of("Msignup.dat", ios::app | ios::binary);
	if (!of)
		cout << "\n\t Unable to open the file! \n";
	else
	{
		of.write((char *)this, sizeof(*this));
		cout << "\n\t Account Created Successfully! \n";
	}
	of.close();
}

void member::Login()
{
	int m;
	string p;
	bool flag = true;
	cout << "\n\t*************** MEMBER-LOGIN *************** \n";
	cout << "\n" << "\t Enter your memberid : ";
	cin >> m;
	cout << "\n\t Enter your password : ";
	cin >> p;
	ifstream r("Msignup.dat", ios::binary);
	if (!r)
		cout << "\n\t Unable to open the file ! \n";
	else
	{
		while (!r.eof())
		{
			r.read((char *)this, sizeof(*this));
			if (p == paSS && m == memberid)
			{
				system("cls");
				cout << "\n\t Login Successful ! \n ";
				cout << "\n\t----------------MEMBER MENU--------------------\n";
			}
			else flag = false;
		}
		if (flag == false)
		{
			system("cls");
			cout << "\n\t Invalid username or email! Try again \n";
			Login();
		}
	}
	r.close();

}
void member::viewmembers()
{
	ifstream r("Msignup.dat", ios::binary);
	if (!r)
		cout << "\n\t Unable to open the file ! \n";
	else
	{
		cout << "\n\t MEMBER DETAILS \n";
		while (!r.eof())
		{
			if (!r.read((char *)this, sizeof(*this)))break;
			Display();
			cout << "\n";
		}
	}
	r.close();
}