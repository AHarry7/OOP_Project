#include "marraige.h"


marraige::marraige()
{
	id = 0;
	name = "unknown";
}

marraige::marraige(int i,string n)
{
	id = i;
	name = n;
}

marraige::~marraige()
{
}

void marraige::Addcard()
{
	cout << "\n\t***********MarraigeCard****************\n";
	cout << "\n\t Enter card name : ";
	cin >> name;
	cout << "\n\t Enter card id : ";
	cin >> id;
	fflush(stdin);
	cout << "\n\t Enter a message for the receiver : ";
	getline(cin, message);
	system("cls");
	cout << "\n\t  CARD CREATED SUCCESSFULLY\n";
	write();
}
void marraige::deletecard()
{
	cout << "\n This card has been deleted! ";
}

void marraige::Displaycards()
{
	cout << "\n\t***********MarraigeCard****************";
	cout << "\n\t ID : " << id;
	cout << "\n\t Name : " << name;
	cout << "\n\t******************************************";
	cout << "\n\t Message for receiver : " << message;
	cout << "\n\t******************************************\n\n";
}

void marraige::write()
{
	ofstream of("Mcard.dat", ios::app | ios::binary);
	if (!of)
		cout << "\n\t Unable to open write! ";
	else
	{
		of.write((char *)this, sizeof(*this));
	}
	of.close();
}

void marraige::viewcard()
{
	ifstream in("Mcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open write! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;
			Displaycards();
			cout << endl;
		}
	}

	in.close();
}

int marraige::getid()
{
	return id;
}



void marraige::search()
{
	int id;
	bool flag = false;
	cout << "\n\t Enter card-id : ";
	cin >> id;
	ifstream in("Mcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;

			if (id == getid())
			{
				flag = true;
				cout << "\n\t FOUND SUCCESSFULLY ! \n\n";
				Displaycards();
				_getch();
				exit(0);
			}
		}
		if (flag == false)
		{
			cout << "\n\t Not found in Marraige-Cards! \n";
		}
	}
	in.close();
}
void marraige::show()
{
	ifstream in("Mcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof *this))break;
			Displaycards();
		}
	}
	in.close();
}