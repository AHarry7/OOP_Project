#pragma once
#include "mehindi.h"
#include <conio.h>
class walima :
	public marraige
{
private:
	
public:
	walima();
	walima(int, string);
	~walima();
	void Addcard();
	void deletecard();
	void Displaycards();
	void write();
	int getid();
	void search();
	void viewcard();
	void show();
};

