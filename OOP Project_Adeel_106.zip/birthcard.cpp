#include "birthcard.h"


birthcard::birthcard()
{
	id = 0;
	name = "unknown";
}
birthcard::birthcard(int i,string n)
{
	id = i;
	name = n;
}
birthcard::~birthcard()
{
}

void birthcard::Addcard()
{
	cout << "\n\t***********BIRTHCARD****************\n";
	cout << "\n\t Enter card name : ";
	cin >> name;
	cout << "\n\t Enter card id : ";
	cin >> id;
	fflush(stdin);
	cout << "\n\t Enter a message for the receiver : ";
	cin.get(message,50);
	system("cls");
	cout << "\n\t  CARD CREATED SUCCESSFULLY\n";
	write();
}
void birthcard::deletecard()
{
	cout << "\n\t This card has been deleted! ";
}

void birthcard::Displaycards()
{
	cout << "\n\t***********BIRTHCARD****************";
	cout << "\n\t ID : " << id;
	cout << "\n\t Name : " << name;
	cout << "\n\t******************************************";
	cout << "\n\t Message for receiver : " << message;
	cout << "\n\t******************************************\n\n";
}

void birthcard::write()
{
	ofstream of("Bcard.dat",ios::app|ios::binary);
	if (!of)
		cout << "\n\t Unable to open write! ";
	else
	{
		of.write((char *)this, sizeof(*this));
	}
	of.close();
}

void birthcard::viewcard()
{
	ifstream in("Bcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open write! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;
			Displaycards();
			cout << endl;
		}
	}

	in.close();
}

int birthcard::getid()
{
	return id;
}

void birthcard::search()
{
	int id;
	bool flag = false;
	cout << "\n\t Enter card-id : ";
	cin >> id;
	ifstream in("Bcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;

			if (id == getid())
			{
				flag = true;
				cout << "\n\t FOUND SUCCESSFULLY ! \n\n";
				Displaycards();
				_getch();
				exit(0);
			}
		}
		if (flag==false)
		{
			cout << "\n\t Not found in Birth-Cards! \n";
		}
	}
	in.close();

}

void birthcard::show()
{
	ifstream in("Bcard.dat",ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof *this))break;
			Displaycards();
		}
	}
	in.close();
}