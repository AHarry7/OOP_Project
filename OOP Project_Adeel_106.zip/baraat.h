#pragma once
#include "walima.h"
class baraat :
	public marraige
{
public:
	baraat();
	baraat(int, string);
	~baraat();
	void Addcard();
	int getid();
	void search();
	void deletecard();
	void Displaycards();
	void write();
	void viewcard();
	void show();
};

