#pragma once
#include "marraige.h"

class mehindi :
	public marraige
{
private: 
	string Name;
public:
	mehindi();
	mehindi(int, string);
	~mehindi();
	void Addcard();
	int getid();
	void search();
	void deletecard();
	void Displaycards();
	void write();
	void viewcard();
	void show();
};

