#include "friendship.h"


friendship::friendship()
{
	id = 0;
	name = "unknown";
}

friendship::friendship(int i,string n)
{
	id = i;
	name = n;
}

friendship::~friendship()
{
}

void friendship::Addcard()
{
	cout << "\n\t***********FriendshipCard****************\n";
	cout << "\n\t Enter card name : ";
	cin >> name;
	cout << "\n\t Enter card id : ";
	cin >> id;
	fflush(stdin);
	cout << "\n\t Enter a message for the receiver : ";
	getline(cin, message);
	system("cls");
	cout << "\n\t  CARD CREATED SUCCESSFULLY\n";
	write();
}
void friendship::deletecard()
{
	cout << "\n This card has been deleted! ";
}

void friendship::Displaycards()
{
	cout << "\n\t***********FriendshipCard****************";
	cout << "\n\t ID : " << id;
	cout << "\n\t Name : " << name;
	cout << "\n\t******************************************";
	cout << "\n\t Message for receiver : " << message;
	cout << "\n\t******************************************\n\n";
}

void friendship::write()
{
	ofstream of("Fcard.dat", ios::app | ios::binary);
	if (!of)
		cout << "\n\t Unable to open write! ";
	else
	{
		of.write((char *)this, sizeof(*this));
	}
	of.close();
}
void friendship::viewcard()
{
	ifstream in("Fcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open write! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;
			Displaycards();
			cout << endl;
		}
	}
	in.close();
}

int friendship::getid()
{
	return id;
}

void friendship::search()
{
	int id;
	bool flag = false;
	cout << "\n\t Enter card-id : ";
	cin >> id;
	ifstream in("Fcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;

			if (id == getid())
			{
				flag = true;
				cout << "\n\t FOUND SUCCESSFULLY ! \n\n";
				Displaycards();
				_getch();
				exit(0);
			}
		}
		if (flag == false)
		{
			cout << "\n\t Not found in Friendship-Cards! \n";
		}
	}
	in.close();
}
void friendship::show()
{
	ifstream in("Fcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof *this))break;
			Displaycards();
		}
	}
	in.close();
}