#include "cards.h"
cards::cards()
{
	id = 0;
	name = "unknown";
	message = "Hi";
}
cards::~cards()
{
}
void cards::Addcard()
{
	walima w;
	mehindi m;
	int ch;
	cout << "\n\t Please select any option ! \n";
	cout << "\n\t1) Birth cards ";
	cout << "\n\t2) Marriage cards ";
	cout << "\n\t3) Friendship cards ";
	cout << "\n\t4) Baraat cards ";
	cout << "\n\t5) Walima cards ";
	cout << "\n\t6) Mehindi cards \n \t \n\t choice : ";
	cin >> ch;
	switch (ch)
	{
	case 1:
		birthcard::Addcard();
		break;
	case 2:
		marraige::Addcard();
		break;
	case 3:
		friendship::Addcard();
		break;
	case 4:
		baraat::Addcard();
		break;
	case 5:
		w.Addcard();
		break;
	case 6:
		m.Addcard();
		break;
	default: cout << "\n\t Invalid choice ! ";
		break;
	}

}

void cards::viewcard()
{
	mehindi m;
	walima t;
	cout << "\n\t**************** SEARCH MENU **************** \n";
	birthcard::search();
	cout << "\n\t Checking in Marraige-Cards! \n";
	marraige::search();
	cout << "\n\t Checking in Friendship-Cards! \n";
	friendship::search();
	cout << "\n\t Checking in Baraat-Cards! \n";
	baraat::search();
	cout << "\n\t Checking in Walima-Cards! \n";
	t.search();
	cout << "\n\t Checking in Mehindi-Cards! \n";
	m.search();

}


void cards::show()
{
	int ch;
	char c = 'y';
	walima w;
	mehindi m;
	do
	{
		cout << "\n\t Please select any option ! \n";
		cout << "\n\t1) Birth cards ";
		cout << "\n\t2) Marriage cards ";
		cout << "\n\t3) Friendship cards ";
		cout << "\n\t4) Baraat cards ";
		cout << "\n\t5) Walima cards ";
		cout << "\n\t6) Mehindi cards \n\n \t choice : ";
		cin >> ch;
		switch (ch)
		{
		case 1:
			birthcard::show();
			break;
		case 2:
			marraige::show();
			break;
		case 3:
			friendship::show();
			break;
		case 4:
			baraat::show();
			break;
		case 5:
			w.show();
			break;
		case 6:
			m.show();
			break;
		default: cout << "\n\t Invalid choice ! ";
			break;
		}
		cout << "\n\t View another? (y/n) : ";
		cin >> c;
		if (c == 'y' || c == 'Y')
		{
			system("cls");
		}
		else if (c == 'n' || c == 'N')
		{
			fflush(stdin);
			system("cls");
			break;
		}
	} while (c == 'y' || c == 'Y');


}

void cards::deletecard()
{
	cout << "\n Cards successfully deleted! ";
}