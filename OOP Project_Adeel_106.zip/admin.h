#include "adminlist.h"
#include "member.h"
#pragma once
class admin:protected adminlist
{
private:
	
public:
	admin();
	~admin();
	void getData();
	void Verifyuser();
	void Deleteadmin();
	void AddMember();
	void deleteMember();
	void Display();
	void Signup();
	void Login();
	void viewadmins();
};

