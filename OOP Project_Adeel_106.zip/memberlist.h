#pragma once
#include <iostream>
using namespace std;
class memberlist
{
protected:
	string name;
	int age;
	string Email;
	int cnic;
	int phone;
public:
	memberlist();
	~memberlist();
	void Verifyuser();
};

