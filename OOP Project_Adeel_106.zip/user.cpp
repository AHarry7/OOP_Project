#include "user.h"
user::user()
{
	id = 0;
	username = "";
	email = "";
	status = "User";
}
user::~user()
{

}
void user::set(int i, string u, string e)
{
	id = i;
	username = u;
	email = e;
}
void user::Verifyuser()
{
	cout << "\n \tThe user is a Normal User ! \n";
}
void user::Display()
{
	cout << "\n\t Status : " << status;
	cout << "\n\t Userid : " << id;
	cout << "\n\t Username : " << username;
	cout << "\n\t Email : " << email;
	
}
void user::Signup() // signup as a normal user
{
	cout << "\n\t --------------SIGN UP----------------\n";
	cout << "\n\t Enter userid of your choice : ";
	cin >> id;
	cout << "\n\t Enter a username of your choice : ";
	cin >> username;
	cout << "\n\t Enter your email : ";
	cin >> email;
	ofstream of("signup.dat", ios::app | ios::binary);
	if (!of)
	{
		cout << "\n\t Unable to open the file! \n";
	}
	else
	{
		of.write((char *)this, sizeof(*this));
		system("cls");
		cout << "\n\t Account Created Successfully! \n";
	}
	of.close();
}

void user::Login()
{
	string u, e;
	bool flag = true;
	cout << "\n\t*************** USER-LOGIN *************** \n";
	cout << "\n" << "\t Enter your username : ";
	cin >> u;
	cout << "\n\t Enter your email : ";
	cin >> e;
	ifstream r("signup.dat", ios::binary);
	if (!r)
	{
		cout << "\n\t Unable to open the file! ";
	}
	else
	{
		while (!r.eof())
		{
			r.read((char *)this, sizeof(*this));
			if (u == username && e == email)
			{
				system("cls");
				cout << "\n\t Login Successful ! \n ";
				cout << "\n\t----------------USER MENU--------------------\n";
			}
			else
			{
				flag = false;
			}
		}
		if (flag == false)
		{
			system("cls");
			cout << "\n\t Invalid username or email! Try again \n";
			Login();
		}
	}

	r.close();
}
void user::viewuser()
{
	ifstream r("signup.dat", ios::binary);
	if (!r)
	{
		cout << "\n\t Unable to open the file! \n";
	}
	else
	{
		cout << "\n\t USER DETAILS \n";
		while (!r.eof())
		{
			if (!r.read((char *)this, sizeof(*this)))break;
			Display();
			cout << "\n";
		}
	}
	r.close();
}

void user::Delete()
{
	string u;
	cout << "\n\t Enter a username to delete : ";
	cin >> u;
	ifstream fin("signup.dat", ios::binary);
	if (!fin)
	{
		cout << "\n\t Unable to open the file! ";
	}
	else
	{
		ofstream fout("temp.dat", ios::binary);
		if (!fout)
		{
			cout << "\n\t Unable to open! ";
		}

		while (!fin.eof())
		{
			fin.read((char *)this, sizeof(*this));
			if (username!=u)
			{
				fout.write((char *)this, sizeof(this));
			}
			fin.read((char *)this, sizeof(*this));
		}
		fin.close();
		fout.close();
		remove("signup.dat");
		rename("temp.dat", "signup.dat");
	}

}
void user::Adduser() // signup As an admin or member
{
	int ch;
	cout << "\n\t Please select any option \n\n";
	cout << "\t 1) Member User \n ";
	cout << "\t 2) Admin User \n\n \t ";
	cin >> ch;
	if (ch == 1)
	{
		member::Signup();
		member::Login();
	}
	else if (ch == 2)
	{
		admin::Signup();
		admin::Login();
	}
	else {
		cout << "\n\t Invalid choice Try again! \n";
		Adduser();
	}
}