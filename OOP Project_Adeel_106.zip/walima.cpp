#include "walima.h"


walima::walima()
{
	id = 0;
	name = "unknown";
}
walima::walima(int i, string n)
{
	id = i;
	name = n;
}

walima::~walima()
{
}

void walima::Addcard()
{
	cout << "\n\t***********WALIMA-CARD****************\n";
	cout << "\n\t Enter card name : ";
	cin >> name;
	cout << "\n\t Enter card id : ";
	cin >> id;
	fflush(stdin);
	cout << "\n\t Enter a message for the receiver : ";
	getline(cin, message);
	system("cls");
	cout << "\n\t  CARD CREATED SUCCESSFULLY\n";
	write();
}
void walima::deletecard()
{
	cout << "\n This card has been deleted! ";
}
void walima::Displaycards()
{
	cout << "\n\t***********WALIMA-CARD****************";
	cout << "\n\t ID : " << id;
	cout << "\n\t Name : " << name;
	cout << "\n\t******************************************";
	cout << "\n\t Message for receiver : " << message;
	cout << "\n\t******************************************\n\n";
}

void walima::write()
{
	ofstream of("Wcard.dat", ios::app | ios::binary);
	if (!of)
		cout << "\n\t Unable to open write! ";
	else
	{
		of.write((char *)this, sizeof(*this));
	}
	of.close();

}

void walima::viewcard()
{
	ifstream in("Wcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open write! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;
			Displaycards();
			cout << endl;
		}
	}

	in.close();
}

void walima::search()
{
	int id;
	bool flag = false;
	cout << "\n\t Enter card-id : ";
	cin >> id;
	ifstream in("Wcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;

			if (id == getid())
			{
				flag = true;
				cout << "\n\t FOUND SUCCESSFULLY ! \n\n";
				Displaycards();
				_getch();
				exit(0);
			}
		}
		if (flag == false)
		{
			cout << "\n\t Not found in Walima-Cards! \n";
		}
	}
	in.close();

}

int walima::getid()
{
	return id;
}

void walima::show()
{
	ifstream in("Wcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof *this))break;
			Displaycards();
		}
	}
	in.close();
}