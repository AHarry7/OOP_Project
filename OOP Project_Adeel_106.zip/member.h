#include "memberlist.h"
#include <fstream>
#include <string>
#pragma once
class member :public memberlist
{
private:
	int memberid;
	string paSS;
	string status;
public:
	member();
	void set(int,string);
	~member();
	void Verifyuser();
	void deleteMember();
	void Display();
	void Signup();
	void Login();
	void viewmembers();
};

