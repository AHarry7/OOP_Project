#pragma once
#include <iostream>
#include <string>
#include <conio.h>
#include <fstream>
using namespace std;
class marraige 
{
protected:
	int id;
	string name,message;
public:
	marraige();
	marraige(int, string);
	~marraige();
	void Addcard();
	void deletecard();
	void Displaycards();
	void viewcard();
	void write();
	int getid();
	void search();
	void show();
};

