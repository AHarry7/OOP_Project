#pragma once
#include "friendship.h"
#include "birthcard.h"
#include "baraat.h"

using namespace std;
class cards:public friendship,birthcard,baraat
{
protected:
	int id;
	string name, message;
public:
	cards();
	~cards();
	void Addcard() ;
	void deletecard() ;
	void viewcard();
	void show();
};

