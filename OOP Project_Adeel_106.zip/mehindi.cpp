#include "mehindi.h"


mehindi::mehindi()
{
	id = 0;
	name = "unknown";
}

mehindi::mehindi(int i,string n)
{
	id = i;
	name = n;
}

mehindi::~mehindi()
{
}

void mehindi::Addcard()
{
	cout << "\n\t***********MEHINDI-CARD****************\n";
	cout << "\n\t Enter card name : ";
	cin >> name;
	cout << "\n\t Enter card id : ";
	cin >> id;
	fflush(stdin);
	cout << "\n\t Enter a message for the receiver : ";
	getline(cin, message);
	system("cls");
	cout << "\n\t  CARD CREATED SUCCESSFULLY\n";
	write();
}
void mehindi::deletecard()
{
	cout << "\n This card has been deleted! ";
}
void mehindi::Displaycards()
{
	cout << "\n\t***********MEHINDI-CARD****************";
	cout << "\n\t ID : " << id;
	cout << "\n\t Name : "<< name;
	cout << "\n\t******************************************";
	cout << "\n\t Message for receiver : " << message;
	cout << "\n\t******************************************\n\n";
}

void mehindi::write()
{
	ofstream of("MMcard.dat", ios::app | ios::binary);
	if (!of)
		cout << "\n\t Unable to open write! ";
	else
	{
		of.write((char *)this, sizeof(*this));
	}
	of.close();
}

void mehindi::viewcard()
{
	ifstream in("MMcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open write! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;
			Displaycards();
			cout << endl;
		}
	}
	in.close();
}

int mehindi::getid()
{
	return id;
}
void mehindi::search()
{
	int id;
	bool flag = false;
	cout << "\n\t Enter card-id : ";
	cin >> id;
	ifstream in("MMcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof(*this)))break;

			if (id == getid())
			{
				flag = true;
				cout << "\n\t FOUND SUCCESSFULLY ! \n\n";
				Displaycards();
				_getch();
				exit(0);
			}
		}
		if (flag == false)
		{
			cout << "\n\t Not found in Any of the Cards! \n";
		}
	}
	in.close();
}
void mehindi::show()
{
	ifstream in("MMcard.dat", ios::binary);
	if (!in)
		cout << "\n\t Unable to open the file! ";
	else
	{
		while (!in.eof())
		{
			if (!in.read((char *)this, sizeof *this))break;
			Displaycards();
		}
	}
	in.close();
}