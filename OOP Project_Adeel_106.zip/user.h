#include <string>
#include "admin.h"
#include "member.h"
#include <iostream>
#include<conio.h>
#include<fstream>
using namespace std;
#pragma once
class user:public admin,public member
{
protected: 
	int id;
	string username;
	string email;
	string status;
public:
	user();
	~user();
	void set(int,string,string);
	void Verifyuser();
	void Adduser();
	void Display();
	void Signup();
	void Login();
	void Delete();
	void viewuser();

};

