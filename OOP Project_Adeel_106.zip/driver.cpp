#include <iostream>
#include "admin.h"
#include "cards.h"
#include "baraat.h"
#include "birthcard.h"
#include "friendship.h"
#include "marraige.h"
#include "user.h"
#include "mehindi.h"
#include "walima.h"
#include <conio.h>
#include <stdio.h>
using namespace std;
int main()
{ 
	char ch,Ch;
	user *u = new user;
	member *m = new member;
	admin *a = new admin;
	cards *c = new cards;
	menu:
	cout << "\n\t********************************* WELCOME TO ELECTRONIC CARD SYSTEM *********************************\n";
	cout << "\n\t  1) Admin Details ";
	cout << "\n\t  2) Member Details ";
	cout << "\n\t  3) User Details ";
	cout << "\n\t  4) Signup as a User";
	cout << "\n\t  5) Addusers (signup) (member/admin) ";
	cout << "\n\t  6) Login as User ";
	cout << "\n\t  7) Login as Member ";
	cout << "\n\t  8) Login as Admin ";
	cout << "\n\t  9) Delete Admin ";
	cout << "\n\t 10) Delete Member ";
	cout << "\n\t 11) Delete User \n\n\t choice : ";
	cin >> ch;
	if (ch == '1')
	{
		system("cls");
		u->viewadmins();   // existing Admins reading data from files
		goto menu;
	}
	else if (ch == '2')
	{
		system("cls");
		u->viewmembers();  // data of existing members from files 
		goto menu;
	}
	else if (ch == '3')
	{
		system("cls");
		u->viewuser();
		goto menu;
	}
	
	else if (ch == '4')
	{
		system("cls");
		u->Signup();     // signup as a user
		u->Login();
	}
	else if (ch == '5')
	{
		system("cls");
		u->Adduser();     // either Admin or Member
	}
	else if (ch == '6')
	{
		system("cls");
		u->Login();       // admin and member class have their separat login system 
	}
	else if (ch == '7')
	{
		system("cls");
		m->Login();
	}
	else if (ch == '8')
	{
		system("cls");
		a->Login();
	}
	else if (ch == '9')
	{
		system("cls");
		a->Deleteadmin();
	}
	else if (ch == '10')
	{
		system("cls");
		m->deleteMember();
	}
	else if (ch == '11')
	{
		system("cls");
		u->Delete();
	}
	
	ccard:
	cout << "\n\t******************* CARD DESIGN MENU *********************************\n";
	cout << "\n\t 1) Add Card ";
	cout << "\n\t 2) Search Card ";
	cout << "\n\t 3) View Cards ";
	cout << "\n\t 4) Delete Cards \n\n\t ";
	cin >> Ch;
	if (Ch == '1')
	{
		system("cls");
		c->Addcard();
		goto ccard;
	}
	else if (Ch == '2')
	{
		system("cls");
		c->viewcard();
	}
	else if (Ch == '3')
	{
		system("cls");
		c->show();
		goto ccard;
	}
	else if (Ch == '4')
	{
		system("cls");
		c->deletecard();
	}
	else
	{
		cout << "\n\t Invalid Choice! Try again ";
	}

	_getch();
}





