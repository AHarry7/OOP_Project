#pragma once
#include <string>
#include <iostream>
#include <conio.h>
#include <fstream>
using namespace std;
class friendship 
{
private:
	int id;
	string name, message;
public:
	friendship();
	friendship(int, string);
	~friendship();
	void Addcard();
	void deletecard();
	void Displaycards();
	void write();
	int getid();
	void viewcard();
	void search();
	void show();
};

