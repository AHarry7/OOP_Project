#include "adminlist.h"
adminlist::adminlist()
{
	admin_id = 1234;
	password = "hello";
	status = "Admin";
}

adminlist::~adminlist()
{
}
void adminlist::Verifyuser()
{
	cout << "\n\t The User is an Admin! \n";
}

