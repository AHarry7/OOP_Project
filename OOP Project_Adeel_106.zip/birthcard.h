#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <conio.h>
#include <stdio.h>
using namespace std;
class birthcard 
{
private:
	int id;
	string name;
	char message[50];
public:
	birthcard();
	birthcard(int, string);
	void Addcard();
	int getid();
	void search();
	void deletecard();
	~birthcard();
	void write();
	void viewcard();
	void Displaycards();
	void show();
};

